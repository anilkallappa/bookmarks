# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Candidate',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('First_name', models.CharField(max_length=50)),
                ('Last_name', models.CharField(max_length=50)),
                ('Qualification', models.CharField(max_length=50)),
                ('City', models.CharField(max_length=50)),
                ('Mobile', models.PositiveIntegerField()),
                ('gender', models.CharField(max_length=4, choices=[('Male', 'Male'), ('Female', 'Female')])),
                ('email', models.EmailField(max_length=254)),
                ('paddr', models.CharField(max_length=100, verbose_name='Address line 1')),
                ('caddr', models.CharField(blank=True, max_length=100, verbose_name='Address line 2')),
                ('yop', models.DateField(null=True)),
                ('dob', models.DateField(null=True)),
                ('sslcper', models.DecimalField(max_digits=10, decimal_places=3)),
                ('puper', models.DecimalField(max_digits=10, decimal_places=3)),
                ('gradper', models.DecimalField(max_digits=10, decimal_places=3)),
                ('college', models.CharField(max_length=250)),
                ('branch', models.CharField(max_length=250)),
                ('updated', models.DateTimeField(null=True)),
            ],
        ),
    ]
