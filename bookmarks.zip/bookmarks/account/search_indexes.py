
from .models import Student
from haystack import indexes
 
 
class StudentIndex(indexes.SearchIndex, indexes.Indexable):
    text = indexes.CharField(document=True, use_template=True)
    fname = indexes.CharField(model_attr='fname')
    lname = indexes.CharField(model_attr='lname')
    Qual  = indexes.CharField(model_attr='Qual')
 
    def get_model(self):
        return Student
 
    def index_queryset(self, using=None):
        return self.get_model().objects.all()