from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth import authenticate, login
from .forms import LoginForm, SearchForm
from django.contrib.auth.decorators import login_required

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView

from account.models import Candidate
from django.core.urlresolvers import reverse_lazy



@login_required
def dashboard(request):
    return render(request, 'account/dashboard.html', {'section': 'dashboard'})


class StudentList(ListView):
    queryset = Candidate.objects.all()
    paginate_by = 8
    template_name = 'account/list.html'

class StudentCreate(CreateView):
    model = Candidate
    fields = ['First_name','Last_name','Qualification','City','Mobile','gender','email','paddr','caddr','yop','dob','sslcper','puper','gradper','college','branch','updated']
    success_url = reverse_lazy('student-list')

class StudentUpdate(UpdateView):
    model = Candidate
    fields = ['First_name','Last_name','Qualification','City','Mobile','gender','email','paddr','caddr','yop','dob','sslcper','puper','gradper','college','branch','updated']
    template_name = 'account/update.html'
    success_url = reverse_lazy('student-list')


class StudentDelete(DeleteView):
	#template_name = 'courses/manage/course/delete.html'
	#success_url = reverse_lazy('manage_course_list')
    model = Candidate
    fields = ['First_name','Last_name','Qualification','City','Mobile','gender','email','paddr','caddr','yop','dob','sslcper','puper','gradper','college','branch','updated']
    template_name = 'account/delete.html'
    success_url = reverse_lazy('student-list')


def student_search(request):
    form = SearchForm()
    if 'query' in request.GET:
        form = SearchForm(request.GET)
        if form.is_valid():
            cd = form.cleaned_data
            results = SearchQuerySet().models(Candidate).filter(content=cd['query']).load_all()
            # count total results
            total_results = results.count()
            return render(request, 'account/search.html', {'form': form,'cd': cd,'results': results,'total_results': total_results})

    return render(request, 'account/search.html', {'form': form,})



