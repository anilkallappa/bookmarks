from django.conf.urls import url
from . import views

from account.views import StudentCreate, StudentUpdate, StudentDelete, StudentList


urlpatterns = [
    # url(r'^login/$', views.user_login, name='login'),

    url(r'^$', views.dashboard, name='dashboard'),

    # login / logout urls
    url(r'^login/$', 'django.contrib.auth.views.login', name='login'),
    url(r'^logout/$', 'django.contrib.auth.views.logout', name='logout'),
    url(r'^logout-then-login/$', 'django.contrib.auth.views.logout_then_login', name='logout_then_login'),


    url(r'add/$', StudentCreate.as_view(), name='student-add'),
    url(r'^list/$', StudentList.as_view(), name='student-list'),
    url(r'^(?P<pk>\d+)/delete/$', StudentDelete.as_view(), name='student-delete'),
    url(r'^(?P<pk>\d+)/update/$', StudentUpdate.as_view(), name='student-edit'),

    url(r'^password-change/$', 'django.contrib.auth.views.password_change', name='password_change'),
    url(r'^password-change/done/$', 'django.contrib.auth.views.password_change_done', name='password_change_done'),

    url(r'^password-reset/$', 'django.contrib.auth.views.password_reset', name='password_reset'),
    url(r'^password-reset/done/$', 'django.contrib.auth.views.password_reset_done', name='password_reset_done'),
    url(r'^password-reset/confirm/(?P<uidb64>[-\w]+)/(?P<token>[-\w]+)/$', 'django.contrib.auth.views.password_reset_confirm', name='password_reset_confirm'),
    url(r'^password-reset/complete/$', 'django.contrib.auth.views.password_reset_complete', name='password_reset_complete'),

    url(r'^search/$', views.student_search, name='student_search'),

]
