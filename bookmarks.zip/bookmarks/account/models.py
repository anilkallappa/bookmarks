from django.db import models

class Candidate(models.Model):
    First_name=models.CharField(max_length=50)
    Last_name = models.CharField(max_length=50)
    Qualification=models.CharField(max_length=50)
    City=models.CharField(max_length=50)
    Mobile=models.PositiveIntegerField()
    GENDER_CHOICES = (
        ('Male', 'Male'),
        ('Female', 'Female'),
    )
    gender = models.CharField(max_length=4, choices=GENDER_CHOICES)
    email = models.EmailField(max_length=254)
    paddr = models.CharField("Address line 1", max_length=100)
    caddr = models.CharField("Address line 2", max_length=100,
                                     blank=True)
    yop = models.DateField(null=True)
    dob = models.DateField(null=True)
    sslcper = models.DecimalField(max_digits=10, decimal_places=3)
    puper = models.DecimalField(max_digits=10, decimal_places=3)
    gradper = models.DecimalField(max_digits=10, decimal_places=3)
    college = models.CharField(max_length=250)
    branch=models.CharField(max_length=250)
    updated = models.DateTimeField(null=True)

