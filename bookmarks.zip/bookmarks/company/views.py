from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth import authenticate, login
from .forms import LoginForm, SearchForm
from django.contrib.auth.decorators import login_required

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView

from company.models import Company,Requirement
from django.core.urlresolvers import reverse_lazy



from .forms import RequirementForm


from django.shortcuts import render, get_object_or_404

def company_list(request):
    company = Company.objects.all()
    return render(request,'company/complist.html',{'company': company})


def company_detail(request, id):
    company = get_object_or_404(Company, id=id)

    # List of active requirements
    requirements = company.requirements.filter(active=True)

    if request.method == 'POST':
        # A Requirement was posted
        requirement_form = RequirementForm(data=request.POST)

        if requirement_form.is_valid():
            # Create Requirement object but don't save to database yet
            new_requirement = requirement_form.save(commit=False)
            # Assign the current post to the comment
            new_requirement.company =  company

            # Save the comment to the database
            new_requirement.save()
    else:
        requirement_form = RequirementForm(data=request.POST)

    return render(request,'company/compdetail.html',{'company': company, 'requirements':requirements, 'requirement_form':requirement_form })

class CompanyList(ListView):
    queryset = Company.objects.all()
    paginate_by = 8
    template_name = 'company/company_list.html'


class CompanyCreate(CreateView):
    model = Company
    fields = ['cname','addr','city','person1','mobile1','email1','person2','mobile2','email2','website']
    success_url = reverse_lazy('company-list')
    template_name = 'company/company_create.html'
    

class CompanyUpdate(UpdateView):
    model = Company
    fields = ['cname','addr','city','person1','mobile1','email1','person2','mobile2','email2','website']
    success_url = reverse_lazy('company-list')
    template_name = 'company/company_update.html'


class CompanyDelete(DeleteView):
    model = Company
    fields = ['cname','addr','city','person1','mobile1','email1','person2','mobile2','email2','website']
    success_url = reverse_lazy('company-list')
    template_name = 'company/company_delete.html'

