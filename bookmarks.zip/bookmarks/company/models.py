from django.db import models

# Create your models here.

from django.core.urlresolvers import reverse

class Company(models.Model):
    cname=models.CharField(max_length=50)
    addr=models.CharField('Address line 1',max_length=150)
    city=models.CharField(max_length=10)
    person1=models.CharField(max_length=50)
    mobile1=models.CharField(max_length=10)
    email1=models.EmailField(max_length=50)
    person2=models.CharField(max_length=50)
    mobile2=models.CharField(max_length=10)
    email2=models.EmailField(max_length=50)
    website=models.URLField(max_length=200)

    def __str__(self):
        return self.cname

    def get_absolute_url(self):
        return reverse('company_detail',args=[self.id])


class Requirement(models.Model):
    company=models.ForeignKey(Company, related_name='requirements')
    jd=models.CharField(max_length=500)
    exp=models.IntegerField()
    eligible=models.CharField(max_length=100)
    perc=models.FloatField(max_length=10)
    skillset=models.CharField(max_length=500)
    jlocation=models.CharField(max_length=250)
    package=models.CharField(max_length=50)
    no_position=models.CharField(max_length=500)
    oncamp=models.BooleanField(default=True)
    created=models.DateTimeField(auto_now_add=True)
    closing=models.DateTimeField(auto_now=True)
    active=models.BooleanField(default=True)

    class Meta:
        ordering = ('created',)

    def __str__(self):
        return self.jd
