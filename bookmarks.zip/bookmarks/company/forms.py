from django import forms
from .models import Requirement


class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)



class SearchForm(forms.Form):
    query = forms.CharField()



class RequirementForm(forms.ModelForm):
    class Meta:
        model = Requirement
        fields = ('jd', 'exp', 'eligible','perc','skillset','jlocation','package','no_position','oncamp',)


