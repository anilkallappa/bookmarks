# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('company', '0002_auto_20171209_2038'),
    ]

    operations = [
        migrations.RenameField(
            model_name='requirement',
            old_name='Closing',
            new_name='closing',
        ),
    ]
