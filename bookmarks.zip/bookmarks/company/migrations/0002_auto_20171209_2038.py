# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('company', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Requirement',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('jd', models.CharField(max_length=500)),
                ('exp', models.IntegerField()),
                ('eligible', models.CharField(max_length=100)),
                ('perc', models.FloatField(max_length=10)),
                ('skillset', models.CharField(max_length=500)),
                ('jlocation', models.CharField(max_length=250)),
                ('package', models.CharField(max_length=50)),
                ('no_position', models.CharField(max_length=500)),
                ('oncamp', models.BooleanField(default=True)),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('Closing', models.DateTimeField(auto_now=True)),
                ('active', models.BooleanField(default=True)),
            ],
            options={
                'ordering': ('created',),
            },
        ),
        migrations.AlterField(
            model_name='company',
            name='email1',
            field=models.EmailField(max_length=50),
        ),
        migrations.AlterField(
            model_name='company',
            name='email2',
            field=models.EmailField(max_length=50),
        ),
        migrations.AddField(
            model_name='requirement',
            name='company',
            field=models.ForeignKey(related_name='requirements', to='company.Company'),
        ),
    ]
