# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Company',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('cname', models.CharField(max_length=50)),
                ('addr', models.CharField(max_length=150, verbose_name='Address line 1')),
                ('city', models.CharField(max_length=10)),
                ('person1', models.CharField(max_length=50)),
                ('mobile1', models.CharField(max_length=10)),
                ('email1', models.EmailField(max_length=10)),
                ('person2', models.CharField(max_length=50)),
                ('mobile2', models.CharField(max_length=10)),
                ('email2', models.EmailField(max_length=10)),
                ('website', models.URLField()),
            ],
        ),
    ]
