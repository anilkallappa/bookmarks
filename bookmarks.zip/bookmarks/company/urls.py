from django.conf.urls import url
from . import views

from company.views import CompanyCreate, CompanyUpdate, CompanyDelete, CompanyList


urlpatterns = [

    url(r'add/$', CompanyCreate.as_view(), name='company-add'),
    url(r'^list/$', CompanyList.as_view(), name='company-list'),
    url(r'^(?P<pk>\d+)/delete/$', CompanyDelete.as_view(), name='company-delete'),
    url(r'^(?P<pk>\d+)/update/$', CompanyUpdate.as_view(), name='company-edit'),

    #url(r'^search/$', views.Company_search, name='company_search'),

    url(r'^nlist$', views.company_list, name='company_list'),
    url(r'^detail/(?P<id>\d+)/$',views.company_detail, name='company_detail'),
]


